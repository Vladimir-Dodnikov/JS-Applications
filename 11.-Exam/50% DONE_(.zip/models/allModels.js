import user from "./user.js";
import articles from "./articles.js";

export default {
    user,
    articles
}