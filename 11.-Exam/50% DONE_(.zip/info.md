controllers: render data between html and database
models: fetch data from database to controllers
templates: render html parts dynamically

I'm using CloudStore in Firebase!