import extend from '../helpers/userState.js';

export default {
    get: {
        partials(ctx) {
            extend(ctx)
                .then(function () {
                    this.partial('../templates/articles/home.hbs');
                });
        }
    }
}