import home from "./home.js";
import user from "./user.js";
import articles from "./articles.js";


export default {
    home,
    user,
    articles
}