import extend from '../helpers/userState.js';
import allModels from '../models/allModels.js'
import objModifier from '../helpers/objModifier.js';

export default {
    get: {
        dashboard(ctx) {
            allModels.articles.getAll().then((resp) => {
                // console.log(resp);
                // console.log(resp.docs);
                // 'resp' is object, 'docs' is prop of resp, 'docs' is arr
                // 'data' is elem of arr, 'data' is object
                const articles = resp.docs.map(objModifier);
                console.log(articles);
                ctx.articles = articles;

                extend(ctx).then(function () {
                    this.partial('../templates/articles/home.hbs')
                })
            })

        },
        create(ctx) {
            extend(ctx).then(function () {
                this.partial('../templates/articles/create.hbs')
            })
        },
        details(ctx) {
            console.log(ctx);
            const {
                articleId
            } = ctx.params;
            // console.log(articleId);

            allModels.articles.getById(articleId)
                .then((resp) => {
                    // console.log(resp);
                    const article = objModifier(resp);
                    // console.log(article);
                    // // ctx.cause = cause;

                    Object.keys(article).forEach((key) => {
                        ctx[key] = article[key];
                    })

                    //canDonate form init
                    // console.log(localeStorage.getItem('userId'));
                    ctx.isCreator = article.uid !== localStorage.getItem('userId');

                    extend(ctx).then(function () {
                        this.partial('../templates/articles/details.hbs')
                    })

                })
                .catch((e) => console.error(e));
        }
    },
    post: {
        create(ctx) {
            // console.log(ctx.params);
            //{ ...ctx.params } - destruct Sammy.Object to object
            const data = {
                ...ctx.params,
                userEmail: localStorage.getItem('userEmail'),
                userId: localStorage.getItem('userId')
            };
            // console.log(data);
            if (data.category !== 'JavaScript' || data.category !== 'C#' ||
                data.category !== 'Java' || data.category !== 'Python') {
                ctx.redirect('#/articles/create')
                throw Error('Category must be JavaScript, C#, Java or Python!')
            }

            allModels.articles.create(data)
                .then((resp) => {
                    // console.log(resp);
                    ctx.redirect('#/articles/home')
                })
                .catch((e) => console.log(e));
        }
    },
    del: {
        close(ctx) {
            const {
                causeId
            } = ctx.params;
            //from cause model
            allModels.cause.close(causeId).then((resp) => {
                ctx.redirect('#/articles/dashboard');
            })

        }
    },
    put: {
        edit(ctx) {
            const {
                causeId,
                currentDonation
            } = ctx.params;

            allModels.cause.getById(causeId).then((resp) => {
                    const cause = objModifier(resp);

                    // cause.collectedFunds += Number(currentDonation);
                    // cause.donors.push(localStorage.getItem('userEmail'));
                    return allModels.cause.donate(causeId, cause);
                })
                .then((resp) => {
                    ctx.redirect('#/articles/home');
                })
        }
    }
}